package com.maid.gardeningfriend;

public interface EnciclopediaInterface {
    void onItemClick(int position);
}