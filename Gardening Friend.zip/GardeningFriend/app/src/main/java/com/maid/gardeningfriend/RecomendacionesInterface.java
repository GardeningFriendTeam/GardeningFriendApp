package com.maid.gardeningfriend;

/**
 * cotiene funcion que identifica el elem clickeado
 * @return int position
 */
public interface RecomendacionesInterface {
    void onItemClick(int position);
    void onFavClick(int position);
}
