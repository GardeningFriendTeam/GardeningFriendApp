package com.maid.gardeningfriend.favoritos;

public interface FavoritosInterface{
    void OninfoFav(int position);
    void OnEliminarFav(int position);
}
