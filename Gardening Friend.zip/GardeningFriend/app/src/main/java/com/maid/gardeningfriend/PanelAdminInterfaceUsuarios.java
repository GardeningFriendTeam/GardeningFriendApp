package com.maid.gardeningfriend;

public interface PanelAdminInterfaceUsuarios {
    void eliminarUserBtn(int position);
    void cambiarRolUserBtn(int position);
}
